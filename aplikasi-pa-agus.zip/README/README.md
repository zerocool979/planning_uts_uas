<!-- PROJECT LOGO -->
<p align="center">
  <img src="https://img.icons8.com/emoji/96/love-letter-emoji.png" width="96" height="96" alt="Love Compatibility Analyzer Logo"/>
</p>

<h1 align="center">💘 Love Compatibility Analyzer 💘</h1>

<p align="center">
  <i>Analyze, predict, and visualize love compatibility using AI — now with User & Admin roles!</i>
</p>

<p align="center">
  <a href="#"><img src="https://img.shields.io/badge/Flask-v2.3+-blue?logo=flask"></a>
  <a href="#"><img src="https://img.shields.io/badge/Python-3.10+-yellow?logo=python"></a>
  <a href="#"><img src="https://img.shields.io/badge/License-MIT-green"></a>
</p>

<hr>

## 🧠 Overview
**Love Compatibility Analyzer** adalah aplikasi berbasis Flask yang menganalisis kecocokan pasangan menggunakan model AI terlatih dari dataset *Speed Dating Data.csv*.  
Versi terbaru ini mendukung **dua role (User & Admin)**, sistem login/register, serta dashboard sederhana.

---

## 🌸 Features
- 🔐 Sistem login & register dengan Flask-Login
- 👤 Role-based access control (User & Admin)
- 💞 Analisis kompatibilitas cinta berbasis model AI (`love_compatibility_model.pkl`)
- 🧮 Prediksi kecocokan dan saran hubungan
- 💬 Fitur feedback hasil analisis
- 📊 Dashboard pengguna dan halaman admin
- 💾 Database otomatis dibuat saat pertama kali dijalankan

---

## 🚀 Getting Started (User Guide)

### ⚙️ 1. Setup Lingkungan
```bash
git clone <repository-url>
cd Love-Compatibility-Analyzer
python -m venv venv
source venv/bin/activate  # (Windows: venv\Scripts\activate)
pip install -r requirements.txt
```

### 🧩 2. Jalankan Aplikasi
Database akan dibuat otomatis saat pertama kali menjalankan aplikasi.
```bash
python run.py
```
Lalu buka browser ke:
```
http://127.0.0.1:5000/
```

### 👥 3. Registrasi dan Login
1. Buka halaman `/register` → buat akun baru.  
   Semua akun baru otomatis memiliki role `'user'`.
2. Login dengan `/login` untuk mengakses dashboard pengguna.

### 🧑‍💼 4. Menjadikan Akun Admin
Setelah mendaftar akun `admin@example.com`, jalankan perintah berikut:
```bash
flask shell -c "from app.models import User, db; u=User.query.filter_by(email='admin@example.com').first(); u.role='admin'; db.session.commit(); print('✅ Role admin berhasil diatur')"
```

### 🧭 5. Akses Dua Role di Browser Berbeda
Gunakan dua browser atau mode incognito:
- **Admin:** login di Chrome biasa → buka `/admin`
- **User:** login di Chrome Incognito → buka `/dashboard`

### 🔑 URL Penting
| Role | Halaman | Keterangan |
|------|----------|------------|
| User | `/dashboard` | Menampilkan hasil analisis pribadi |
| Admin | `/admin` | Mengelola semua user & analisis |

---

## 💻 Developer Guide

### 🧩 Struktur Proyek
```
Love-Compatibility-Analyzer/
│
├── run.py
├── config.py
├── requirements.txt
├── love_compatibility_model.pkl
│
├── app/
│   ├── __init__.py
│   ├── models.py         # termasuk kolom 'role'
│   ├── forms.py
│   ├── main/
│   │   ├── routes.py     # berisi route admin & user
│   │   └── main.py
│   └── templates/
│       ├── base.html
│       ├── dashboard.html
│       ├── admin_dashboard.html
│       ├── login.html
│       └── register.html
│
└── pelatihan_model_lanjutan.py  # script untuk melatih ulang model AI
```

### 🤖 Tentang Model AI
Model digunakan untuk memprediksi tingkat kecocokan berdasarkan data pelatihan dari `Speed Dating Data.csv`.  
File model tersimpan sebagai:
```
love_compatibility_model.pkl
```

> Model ini diload di route prediksi dan digunakan untuk menghitung skor cinta berdasarkan input pengguna.

### 📈 Melatih Ulang Model (Opsional)
Jika ingin melatih ulang model:
```bash
python pelatihan_model_lanjutan.py
```
File `.pkl` baru akan menggantikan model lama secara otomatis.

### 🧱 Database
- Menggunakan SQLite bawaan Flask (`instance/app.db`).
- Dibuat otomatis saat aplikasi pertama kali dijalankan.
- Tidak perlu migrasi manual.
```python
with app.app_context():
    db.create_all()
```

### 🧑‍💻 Menambahkan Role Baru (Opsional)
Jika ingin menambah role lain seperti `moderator`, cukup tambahkan nilai default baru di kolom `role` pada `models.py`.

---

## 🧾 Troubleshooting
Jika database tidak muncul:
```bash
rm -rf instance/app.db
python run.py
```
Jika error model:
Pastikan file `love_compatibility_model.pkl` berada di direktori utama proyek.

---

## 💬 Credits
Dikembangkan oleh Bilal dan tim untuk pembelajaran Flask & AI Integration.  
Terinspirasi oleh dataset *Speed Dating Experiment (Kaggle)*.

---

## 📄 License
MIT License © 2025 — Love Compatibility Analyzer

---

# 🧹 Bagian Lama (Tidak Lagi Diperlukan)
# - Inisialisasi database manual via flask shell telah diganti menjadi otomatis di run.py
# - File konfigurasi lama yang mengatur SQLAlchemy URL tidak wajib diubah
# - Route debug dan endpoint test lama dapat dihapus jika tidak relevan
# - Model AI dummy telah digantikan oleh love_compatibility_model.pkl yang asli

